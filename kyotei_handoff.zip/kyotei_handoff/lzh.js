// LZH (-lh5-/-lh6-/-lh7-/-lh0-) 解凍。公式データ（mbrace）の日別ファイル用
"use strict";
function decodeLH(src, origSize, dicbit) {
  const NC = 510, NT = 19, CBIT = 9, TBIT = 5;
  const NP = dicbit + 1, PBIT = dicbit <= 13 ? 4 : 5;
  const out = Buffer.alloc(origSize);
  let pos = 0, bitbuf = 0, subbitbuf = 0, bitcount = 0;
  function fillbuf(n) {
    bitbuf = (bitbuf << n) & 0xffff;
    while (n > bitcount) {
      n -= bitcount;
      bitbuf |= (subbitbuf << n) & 0xffff;
      subbitbuf = pos < src.length ? src[pos++] : 0;
      bitcount = 8;
    }
    bitcount -= n;
    bitbuf |= subbitbuf >> bitcount;
  }
  function getbits(n) { const x = bitbuf >> (16 - n); fillbuf(n); return x; }
  const left = new Uint16Array(2 * NC), right = new Uint16Array(2 * NC);
  const c_len = new Uint8Array(NC), pt_len = new Uint8Array(0x80);
  const c_table = new Uint16Array(4096), pt_table = new Uint16Array(256);
  function makeTable(nchar, bitlen, tablebits, table) {
    const count = new Uint32Array(17), weight = new Uint32Array(17), start = new Uint32Array(18);
    for (let i = 0; i < nchar; i++) count[bitlen[i]]++;
    start[1] = 0;
    for (let i = 1; i <= 16; i++) start[i + 1] = (start[i] + (count[i] << (16 - i)));
    const jut = 16 - tablebits;
    for (let i = 1; i <= tablebits; i++) { start[i] >>>= jut; weight[i] = 1 << (tablebits - i); }
    for (let i = tablebits + 1; i <= 16; i++) weight[i] = 1 << (16 - i);
    let i = (start[tablebits + 1] & 0xffff) >>> jut;
    if (i !== 0) { const k = 1 << tablebits; while (i !== k) table[i++] = 0; }
    let avail = nchar; const mask = 1 << (15 - tablebits);
    for (let ch = 0; ch < nchar; ch++) {
      const len = bitlen[ch]; if (len === 0) continue;
      const nextcode = start[len] + weight[len];
      if (len <= tablebits) {
        for (let j = start[len]; j < nextcode; j++) table[j] = ch;
      } else {
        let k = start[len];
        let arr = table, idx = k >>> jut, n = len - tablebits;
        while (n !== 0) {
          if (arr[idx] === 0) { right[avail] = left[avail] = 0; arr[idx] = avail++; }
          const node = arr[idx];
          if (k & mask) { arr = right; } else { arr = left; }
          idx = node; k = (k << 1) & 0xffff; n--;
        }
        arr[idx] = ch;
      }
      start[len] = nextcode;
    }
  }
  function readPtLen(nn, nbit, ispecial) {
    const n = getbits(nbit);
    if (n === 0) {
      const c = getbits(nbit);
      for (let i = 0; i < nn; i++) pt_len[i] = 0;
      for (let i = 0; i < 256; i++) pt_table[i] = c;
      return;
    }
    let i = 0;
    while (i < n) {
      let c = bitbuf >> 13;
      if (c === 7) { let m = 1 << 12; while (m & bitbuf) { m >>= 1; c++; } }
      fillbuf(c < 7 ? 3 : c - 3);
      pt_len[i++] = c;
      if (i === ispecial) { let z = getbits(2); while (z-- > 0) pt_len[i++] = 0; }
    }
    while (i < nn) pt_len[i++] = 0;
    makeTable(nn, pt_len, 8, pt_table);
  }
  function readCLen() {
    const n = getbits(CBIT);
    if (n === 0) {
      const c = getbits(CBIT);
      for (let i = 0; i < NC; i++) c_len[i] = 0;
      for (let i = 0; i < 4096; i++) c_table[i] = c;
      return;
    }
    let i = 0;
    while (i < n) {
      let c = pt_table[bitbuf >> 8];
      if (c >= NT) { let m = 1 << 7; do { c = (bitbuf & m) ? right[c] : left[c]; m >>= 1; } while (c >= NT); }
      fillbuf(pt_len[c]);
      if (c <= 2) {
        if (c === 0) c = 1; else if (c === 1) c = getbits(4) + 3; else c = getbits(CBIT) + 20;
        while (c-- > 0) c_len[i++] = 0;
      } else c_len[i++] = c - 2;
    }
    while (i < NC) c_len[i++] = 0;
    makeTable(NC, c_len, 12, c_table);
  }
  function decodeC() {
    let j = c_table[bitbuf >> 4];
    if (j >= NC) { let m = 1 << 3; do { j = (bitbuf & m) ? right[j] : left[j]; m >>= 1; } while (j >= NC); }
    fillbuf(c_len[j]); return j;
  }
  function decodeP() {
    let j = pt_table[bitbuf >> 8];
    if (j >= NP) { let m = 1 << 7; do { j = (bitbuf & m) ? right[j] : left[j]; m >>= 1; } while (j >= NP); }
    fillbuf(pt_len[j]);
    if (j !== 0) j = (1 << (j - 1)) + getbits(j - 1);
    return j;
  }
  fillbuf(16);
  let blocksize = 0, o = 0;
  while (o < origSize) {
    if (blocksize === 0) {
      blocksize = getbits(16);
      readPtLen(NT, TBIT, 3); readCLen(); readPtLen(NP, PBIT, -1);
    }
    blocksize--;
    const c = decodeC();
    if (c < 256) out[o++] = c;
    else {
      let len = c - 256 + 3; const d = decodeP() + 1;
      let from = o - d;
      while (len-- > 0 && o < origSize) { out[o] = from >= 0 ? out[from] : 0x20; o++; from++; }
    }
  }
  return out;
}
// アーカイブ内の全ファイルを取り出す
function extractLzh(buf) {
  const files = []; let p = 0;
  while (p < buf.length && buf[p] !== 0) {
    const level = buf[p + 20];
    const method = buf.toString("latin1", p + 2, p + 7);
    let comp = buf.readUInt32LE(p + 7); const orig = buf.readUInt32LE(p + 11);
    let dataStart, name = "";
    if (level === 0 || level === 1) {
      const hsize = buf[p];
      const nlen = buf[p + 21]; name = buf.toString("latin1", p + 22, p + 22 + nlen);
      dataStart = p + 2 + hsize;
      if (level === 1) {
        let ext = buf.readUInt16LE(dataStart - 2);
        while (ext) { comp -= ext; dataStart += ext; ext = buf.readUInt16LE(dataStart - 2); }
      }
    } else if (level === 2) {
      dataStart = p + buf.readUInt16LE(p);
    } else throw new Error("unsupported header level " + level);
    const data = buf.subarray(dataStart, dataStart + comp);
    let content;
    if (method === "-lh0-") content = Buffer.from(data);
    else if (method === "-lh5-") content = decodeLH(data, orig, 13);
    else if (method === "-lh6-") content = decodeLH(data, orig, 15);
    else if (method === "-lh7-") content = decodeLH(data, orig, 16);
    else throw new Error("unsupported method " + method);
    files.push({ name, content });
    p = dataStart + comp;
  }
  return files;
}
module.exports = { extractLzh };
