import numpy as np, sys, json, features as fe, model as M, evaluate as E
R=fe.load('races.json'); A=fe.build(R); F=fe.derived(A)
cut=sys.argv[1] if len(sys.argv)>1 else '20260921'
tr=A['date']<cut; va=~tr
sl=lambda D,m:{k:v[m] for k,v in D.items()}
At,Ft,Av,Fv=sl(A,tr),sl(F,tr),sl(A,va),sl(F,va)
print('train',tr.sum(),'valid',va.sum())
lam={'_':1e-3,'V':8,'VD':8}
# 基準：コースだけ（場の傾向・展開表のみ）
L0=M.Layout([],[]); th0,_=M.fit(At,Ft,L0,lam)
E.show('コースだけ',E.metrics(M.trifecta_probs(th0,Av,Fv,L0),Av))
L=M.Layout(M.FEATS,M.FEATS); th,r=M.fit(At,Ft,L,lam)
m=E.metrics(M.trifecta_probs(th,Av,Fv,L),Av); E.show('全要素',m)
p=L.unpack(th); print('頭',dict(zip(L.fh,p['B'].round(3))),'\nヒモ',dict(zip(L.fm,p['G'].round(3))))
np.save('theta.npy',th)
