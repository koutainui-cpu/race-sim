"""買い方ごとの回収率（実際の最終オッズ・払戻で計算）
前半の日付で「モデルとオッズの混ぜ方」「期待値の基準」「ランクの境目」を決め、後半の日付で確かめる。"""
import numpy as np, sys, itertools
d = np.load('bt_data.npz')
P, odds, tri, pay, date = d['P'], d['odds'], d['tri'], d['pay'], d['date']
course = d['course']
n = len(P); idx = np.arange(n)
valid = ~np.isnan(odds)
inv = np.where(valid, 1 / np.where(valid, odds, 1), 0)
Q = inv / inv.sum((1, 2, 3), keepdims=True)                       # 市場の確率（控除分を除いて正規化）
hit = np.zeros_like(P, bool); hit[idx, tri[:, 0], tri[:, 1], tri[:, 2]] = True
dates = sorted(set(date)); half = dates[len(dates) // 2]
A_ = date < half; B_ = ~A_
if len(sys.argv) > 1 and sys.argv[1] == 'all': A_ = np.ones(n, bool); B_ = A_

def blend(a, b):
    X = np.where(valid, np.power(np.maximum(P, 1e-12), a) * np.power(np.maximum(Q, 1e-12), b), 0)
    return X / X.sum((1, 2, 3), keepdims=True)

def ll(X, m): return float(-np.log(X[idx[m], tri[m, 0], tri[m, 1], tri[m, 2]] + 1e-12).mean())

# 1) 混ぜ方を前半で決める
best = None
for a in np.arange(0, 1.61, .1):
    for b in np.arange(0, 1.61, .1):
        if a == 0 and b == 0: continue
        v = ll(blend(a, b), A_)
        if best is None or v < best[0]: best = (v, a, b)
_, a, b = best
Pb = blend(a, b)
print(f'混ぜ方 モデル^{a:.1f} × オッズ^{b:.1f}   3連単LL 前半: モデル {ll(P,A_):.3f} 市場 {ll(Q,A_):.3f} 混合 {ll(Pb,A_):.3f}  後半: モデル {ll(P,B_):.3f} 市場 {ll(Q,B_):.3f} 混合 {ll(Pb,B_):.3f}')

head1 = np.zeros_like(P, bool)
c0 = course - 1
for i in range(6): head1[:, i, :, :] = (c0[:, i] == 0)[:, None, None]

def run(X, m, thr, cut_odds=0, cut_thr=9, minp=0.0, maxb=99):
    EV = X * np.where(valid, odds, 0)
    buy = valid & (EV >= thr) & (X >= minp)
    buy &= ~(head1 & (np.where(valid, odds, 0) < cut_odds) & (EV < cut_thr))   # ② 1号艇頭の安いオッズ
    if maxb < 99:  # 期待値の高い順に上限まで
        flat = np.where(buy, EV, -1).reshape(n, -1); order = np.argsort(-flat, 1)[:, :maxb]
        keep = np.zeros_like(flat, bool); np.put_along_axis(keep, order, True, 1); buy &= keep.reshape(buy.shape)
    buy[~m] = False
    stake = buy.sum() * 100; ret = (buy & hit).sum((1, 2, 3)) * pay
    races = buy.any((1, 2, 3))
    return dict(stake=int(stake), ret=float(ret.sum()), roi=float(ret.sum() / max(stake, 1)), races=int(races.sum()),
                hits=int((buy & hit).any((1, 2, 3)).sum()), bets=int(buy.sum()), buy=buy, EV=EV, per_race_ret=ret)

def boot(res, m, B=2000, seed=0):
    r = np.random.default_rng(seed); ids = np.where(m)[0]
    st = res['buy'].sum((1, 2, 3))[ids] * 100.0; rt = res['per_race_ret'][ids]
    s = []
    for _ in range(B):
        k = r.integers(0, len(ids), len(ids)); s.append(rt[k].sum() / max(st[k].sum(), 1))
    return np.percentile(s, [5, 95])

print('\n== 期待値の基準ごと（後半＝調整に使っていない日）')
for name, X in (('モデルだけ', P), ('混合', Pb)):
    for thr in (1.0, 1.2, 1.5, 2.0):
        r = run(X, B_, thr); lo, hi = boot(r, B_)
        print(f'  {name:6s} 期待値≥{thr:.1f}: {r["races"]}レース {r["bets"]}点 的中{r["hits"]} 回収率 {r["roi"]*100:6.1f}%  (90%幅 {lo*100:.0f}〜{hi*100:.0f}%)')

print('\n== ②1号艇頭の安いオッズを切る（混合・期待値≥1.2）')
for co in (0, 10, 20, 30):
    r = run(Pb, B_, 1.2, cut_odds=co, cut_thr=1.6); lo, hi = boot(r, B_)
    print(f'  1号艇頭 {co}倍未満を切る（期待値1.6以上は残す）: {r["bets"]}点 回収率 {r["roi"]*100:6.1f}% (90%幅 {lo*100:.0f}〜{hi*100:.0f}%)')

# 3) ランク：レースごとの「期待値の上積み合計」で前半の分位点から境目を決める
r_all = run(Pb, np.ones(n, bool), 1.2, cut_odds=20, cut_thr=1.6)
score = np.where(r_all['buy'], r_all['EV'] - 1, 0).sum((1, 2, 3))
sA = score[A_ & (score > 0)]
cuts = np.quantile(sA, [0.5, 0.75, 0.9]) if len(sA) > 10 else [0.5, 1, 2]
rank = np.select([score >= cuts[2], score >= cuts[1], score >= cuts[0], score > 0], ['S', 'A', 'B', 'C'], 'D')
print('\n== ランク別（後半）  境目', np.round(cuts, 2))
for k in 'SABCD':
    m = B_ & (rank == k)
    if k == 'D': print(f'  D: {m.sum()}レース（買い目なし）'); continue
    st = r_all['buy'][m].sum() * 100; rt = r_all['per_race_ret'][m].sum()
    print(f'  {k}: {m.sum()}レース  {r_all["buy"][m].sum()}点  回収率 {rt/max(st,1)*100:6.1f}%')
np.savez('strategy_out.npz', a=a, b=b, cuts=cuts)
