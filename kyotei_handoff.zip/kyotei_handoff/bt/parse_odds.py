"""公式サイトの3連単オッズページ -> 全120通りのオッズ"""
import re, gzip, os, sys, json, glob
TD = re.compile(r'<td class="([^"]*)"(?: rowspan="\d+")?>([^<]*)</td>')
def parse(html):
    i = html.find('oddsPoint')
    if i < 0: return None
    s = html.rfind('<tbody', 0, i); e = html.find('</tbody>', i)
    body = html[s:e]
    out = {}
    second = [None] * 6
    for row in body.split('<tr>')[1:]:
        cells = re.findall(r'<td class="([^"]*)"( rowspan="\d+")?>([^<]*)</td>', row)
        col = 0; k = 0
        while k < len(cells) and col < 6:
            cls, rs, txt = cells[k]
            if rs: second[col] = int(txt); k += 1; cls, rs, txt = cells[k]
            third = int(txt); k += 1
            cls, rs, txt = cells[k]; k += 1
            try: o = float(txt)
            except: o = None
            out[f'{col}-{second[col]-1}-{third-1}'] = o
            col += 1
    return out if len(out) == 120 else None
if __name__ == '__main__':
    res = {}; bad = 0
    for f in sorted(glob.glob(os.path.join(sys.argv[1], '*.html.gz'))):
        d, j, r = os.path.basename(f)[:-8].split('_')
        try: o = parse(gzip.open(f, 'rt', encoding='utf-8', errors='ignore').read())
        except Exception as e: o = None
        if o: res[f'{d}_{j}_{int(r)}'] = o
        else: bad += 1
    json.dump(res, open(sys.argv[2], 'w'))
    print('ok', len(res), 'bad', bad)
