"""調整に使っていない期間で、予想と実際の結果を照合する"""
import numpy as np, model as M

COURSE_LABEL = ['1コース', '2コース', '3コース', '4コース', '5コース', '6コース']


def metrics(P, A):
    n = len(A['date']); idx = np.arange(n); t = A['tri']
    pt = P[idx, t[:, 0], t[:, 1], t[:, 2]]
    pw = P.sum((2, 3))
    out = {}
    out['races'] = n
    out['win_ll'] = float(-np.log(pw[idx, t[:, 0]] + 1e-12).mean())
    out['win_hit'] = float((pw.argmax(1) == t[:, 0]).mean())
    out['tri_ll'] = float(-np.log(pt + 1e-12).mean())
    mk = np.clip(75.0 / A['pay'], 1e-6, 1)          # 払戻から逆算した市場の確率
    out['mkt_ll'] = float(-np.log(mk).mean())
    out['uniform_ll'] = float(np.log(120))
    flat = P.reshape(n, -1); order = np.argsort(-flat, 1)
    actual = t[:, 0] * 36 + t[:, 1] * 6 + t[:, 2]
    for k in (1, 3, 5, 10):
        hit = (order[:, :k] == actual[:, None]).any(1)
        out[f'top{k}_hit'] = float(hit.mean())
        out[f'top{k}_roi'] = float((A['pay'] * hit).sum() / (100 * k * n))
    # コース別：予想1着率・予想2〜3着率 と 実際
    c = A['course'] - 1
    p23 = P.sum((1, 3)) + P.sum((1, 2))
    rows = []
    for k in range(6):
        m = (c == k)
        aw = (t[:, 0][:, None] == np.arange(6)) & m
        a23 = ((t[:, 1][:, None] == np.arange(6)) | (t[:, 2][:, None] == np.arange(6))) & m
        rows.append(dict(course=k + 1, pred_win=float(pw[m].mean()), act_win=float(aw.sum() / m.sum()),
                         pred_23=float(p23[m].mean()), act_23=float(a23.sum() / m.sum())))
    out['by_course'] = rows
    # 1着率の当てはまり（予想確率帯ごとの実際）
    bins = [0, .1, .2, .3, .4, .5, .6, .7, .8, 1.01]
    act = (t[:, 0][:, None] == np.arange(6))
    cal = []
    for a, b in zip(bins[:-1], bins[1:]):
        m = (pw >= a) & (pw < b)
        if m.sum() >= 30: cal.append(dict(lo=a, hi=b, n=int(m.sum()), pred=float(pw[m].mean()), act=float(act[m].mean())))
    out['calib'] = cal
    return out


def show(name, m):
    print(f"== {name}  ({m['races']}レース)")
    print(f"  1着 対数損失 {m['win_ll']:.3f}  本命的中 {m['win_hit']*100:.1f}%")
    print(f"  3連単 対数損失 {m['tri_ll']:.3f}  市場 {m['mkt_ll']:.3f}  当てずっぽう {m['uniform_ll']:.3f}")
    print('  ' + '  '.join(f"上位{k}点 的中{m[f'top{k}_hit']*100:.1f}% 回収{m[f'top{k}_roi']*100:.0f}%" for k in (1, 3, 5, 10)))
    print('  コース別  予想1着/実際  予想2-3着/実際')
    for r in m['by_course']:
        print(f"   {r['course']}  {r['pred_win']*100:5.1f}/{r['act_win']*100:5.1f}   {r['pred_23']*100:5.1f}/{r['act_23']*100:5.1f}")
