"""レース一覧 -> 学習・検証用の配列（平均STとF数は「そのレースより前」の成績だけから計算）"""
import json, numpy as np, collections, datetime as dt

VENUES = ['01','02','03','04','05','06','07','08','09','10','11','12',
          '13','14','15','16','17','18','19','20','21','22','23','24']
VNAME = ['桐生','戸田','江戸川','平和島','多摩川','浜名湖','蒲郡','常滑','津','三国','びわこ','住之江',
         '尼崎','鳴門','丸亀','児島','宮島','徳山','下関','若松','芦屋','福岡','唐津','大村']
DIR8 = ['北','北東','東','南東','南','南西','西','北西']


def load(path):
    races = json.load(open(path))
    races.sort(key=lambda r: (r['date'], r['jcd'], r['rno']))
    return races


def build(races, st_window=30, st_min=5, f_days=180):
    hist = collections.defaultdict(list)       # 登番 -> [(date, st)]
    fhist = collections.defaultdict(list)      # 登番 -> [date of F]
    out = dict(date=[], venue=[], course=[], win=[], win2=[], boat=[], lwin=[], mot=[], ten=[], pst=[], hasst=[], fcnt=[],
               wind=[], wdir=[], wave=[], tri=[], pay=[], pop=[], rno=[])
    cur = None; pending = []
    def flush():
        for toban, d, st, f in pending:
            if st is not None and not f and 0 < st < 0.6: hist[toban].append(st)
            if f: fhist[toban].append(d)
        pending.clear()
    for r in races:
        d = dt.date(int(r['date'][:4]), int(r['date'][4:6]), int(r['date'][6:]))
        if d != cur: flush(); cur = d
        bs = r['boats']
        cs = [b['course'] for b in bs]
        if None in cs or len(set(cs)) != 6: cs = [1, 2, 3, 4, 5, 6]
        pst, has, fc = [], [], []
        for b in bs:
            h = hist[b['toban']][-st_window:]
            has.append(len(h) >= st_min)
            pst.append(float(np.mean(h)) if len(h) >= st_min else np.nan)
            fc.append(sum(1 for x in fhist[b['toban']] if (d - x).days <= f_days))
        out['date'].append(r['date']); out['venue'].append(VENUES.index(r['jcd'])); out['rno'].append(r['rno'])
        out['course'].append(cs)
        out['win'].append([b['win'] for b in bs]); out['lwin'].append([b['lwin'] for b in bs])
        out['win2'].append([b['win2'] or 0 for b in bs]); out['boat'].append([b['boat'] or 0 for b in bs])
        out['mot'].append([b['mot'] for b in bs])
        out['ten'].append([b['ten'] if b['ten'] else np.nan for b in bs])
        out['pst'].append(pst); out['hasst'].append(has); out['fcnt'].append(fc)
        out['wind'].append(r['wind']); out['wave'].append(r['wave'])
        out['wdir'].append(DIR8.index(r['wdir']) if r['wdir'] in DIR8 else -1)
        out['tri'].append([x - 1 for x in r['tri']]); out['pay'].append(r['pay']); out['pop'].append(r['pop'])
        for b in bs: pending.append((b['toban'], d, b['st'], b['fst']))
    flush()
    return {k: np.array(v) for k, v in out.items()}


def derived(A, st_fill=0.17, f_add=0.02):
    """各艇の偏差・想定ST・スリット差（アプリと同じ定義）"""
    n = len(A['date'])
    def dev(x):
        x = x.astype(float); m = np.nanmean(x, axis=1, keepdims=True)
        d = x - m; d[np.isnan(d)] = 0; return d
    dwin = dev(A['win']); dlwin = dev(A['lwin']); dmot = dev(A['mot'])
    dten = -dev(A['ten'])                        # 展示は速い（小さい）ほどプラス
    pst = np.where(np.isnan(A['pst']), st_fill, A['pst']) + f_add * (A['fcnt'] > 0)
    cs = A['course']
    adv = np.zeros((n, 6))
    for i in range(6):
        inner = cs < cs[:, [i]]
        cnt = inner.sum(1)
        mean_in = np.where(cnt > 0, (pst * inner).sum(1) / np.maximum(cnt, 1), 0)
        others = (pst.sum(1) - pst[:, i]) / 5
        adv[:, i] = np.where(cnt > 0, mean_in - pst[:, i], 0.5 * (others - pst[:, i]))
    c = A['course']
    o = dict(dwin=dwin, dlwin=dlwin, dmot=dmot, dten=dten, pst=pst, adv=adv, fpos=(A['fcnt'] > 0).astype(float))
    o['dwin2'] = dev(A['win2']) / 10 if 'win2' in A else np.zeros_like(dwin)
    o['dboat'] = dev(A['boat']) if 'boat' in A else np.zeros_like(dwin)
    o['dwin_c1'] = dwin * (c == 1); o['adv_c1'] = adv * (c == 1); o['adv_out'] = adv * (c >= 4)
    o['dten_c1'] = dten * (c == 1)
    # ヒモ用：1着艇がまくった（外から）とき内側が飲まれる…は別途
    return o
