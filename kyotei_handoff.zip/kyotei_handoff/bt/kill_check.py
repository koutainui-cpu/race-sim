"""「消し」の確認：モデル確率 ÷ 市場確率（控除補正1.337）の比ごとに、全組を100円ずつ買った場合の回収率（8月・9月）"""
import numpy as np
d=np.load('bt_augsep.npz'); P,odds,tri,pay,date,course=d['P'],d['odds'],d['tri'],d['pay'],d['date'],d['course']
n=len(P); idx=np.arange(n); valid=~np.isnan(odds); o=np.where(valid,odds,1)
hit=np.zeros_like(P,bool); hit[idx,tri[:,0],tri[:,1],tri[:,2]]=True
r=P/((1/o)/1.337)
waku=(course==np.arange(1,7)).all(1)
for nm,m in (('8月',date<'20260901'),('9月',date>='20260901')):
    print(nm,f'{m.sum()}レース 枠なり以外の割合 {(~waku[m]).mean()*100:.1f}%')
    M=valid&m[:,None,None,None]
    tot=(hit&M).sum((1,2,3))*pay; print('  全組を買った場合の回収率',round(tot.sum()/(M.sum()*100)*100,1),'%')
    for lo,hi in ((0,.7),(.7,1),(1,1.3),(1.3,1.6),(1.6,99)):
        mm=M&(r>=lo)&(r<hi); ret=((hit&mm).sum((1,2,3))*pay).sum()
        print(f'  比 {lo}〜{hi}: {mm.sum()}点 回収率 {ret/(mm.sum()*100)*100:.1f}%')
