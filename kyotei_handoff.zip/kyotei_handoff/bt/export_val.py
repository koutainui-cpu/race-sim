import json,sys,numpy as np,features as fe
R=fe.load('races.json'); A=fe.build(R); cut=sys.argv[1]
m=A['date']>=cut; out=[]
for i in np.where(m)[0]:
    bs=[dict(c=int(A['course'][i][j]),win=float(A['win'][i][j]),mot=float(A['mot'][i][j]),
      ten=None if np.isnan(A['ten'][i][j]) else float(A['ten'][i][j]),
      st=None if np.isnan(A['pst'][i][j]) else float(A['pst'][i][j]),f=int(A['fcnt'][i][j])) for j in range(6)]
    out.append(dict(boats=bs,wind=int(A['wind'][i]),wave=int(A['wave'][i]),tri=[int(x) for x in A['tri'][i]],pay=int(A['pay'][i])))
json.dump(out,open('val.json','w')); print(len(out))
