import numpy as np, sys, features as fe, model as M, evaluate as E
R=fe.load('races.json'); A=fe.build(R); F=fe.derived(A)
cut=sys.argv[1]; tr=A['date']<cut; va=~tr
sl=lambda D,m:{k:v[m] for k,v in D.items()}
At,Ft,Av,Fv=sl(A,tr),sl(F,tr),sl(A,va),sl(F,va)
lam={'_':1e-3,'V':8,'VD':8}
base=['dwin','dlwin','dmot','dten','adv','fpos']
V={'基本':(base,base),
   '+2連率・ボート':(base+['dwin2','dboat'],base+['dwin2','dboat']),
   '+コース別の効き':(base+['dwin_c1','adv_c1','adv_out','dten_c1'],base),
   '+両方':(base+['dwin2','dboat','dwin_c1','adv_c1','adv_out','dten_c1'],base+['dwin2','dboat'])}
for name,(fh,fm) in V.items():
    L=M.Layout(fh,fm); th,r=M.fit(At,Ft,L,lam)
    m=E.metrics(M.trifecta_probs(th,Av,Fv,L),Av)
    print(f"{name:12s} 1着LL {m['win_ll']:.4f} 本命 {m['win_hit']*100:.1f}% 3連単LL {m['tri_ll']:.4f}  市場 {m['mkt_ll']:.4f}")
