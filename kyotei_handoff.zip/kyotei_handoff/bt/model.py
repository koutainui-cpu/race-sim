"""頭（1着）とヒモ（2・3着）を別々に持つ確率モデル。アプリと同じ式で、過去データから効き具合を推定する。
頭 : s_i = P[c] + V[場,c] + Σβ·特徴 + 風速·W[c] + 波高·H[c] + 風速·[c=1]·VD[場,風向]
ヒモ: q_j = D[1着艇のコース, c_j] + Σγ·特徴      （2着・3着は残りの艇から順に選ぶ）
"""
import numpy as np
from scipy.optimize import minimize

FEATS = ['dwin', 'dlwin', 'dmot', 'dten', 'adv', 'fpos']


class Layout:
    def __init__(self, feats_h, feats_m):
        self.fh, self.fm = feats_h, feats_m
        self.parts = [('P', (6,)), ('V', (24, 6)), ('B', (len(feats_h),)), ('W', (6,)), ('H', (6,)),
                      ('VD', (24, 8)), ('D', (6, 6)), ('G', (len(feats_m),))]
        self.size = sum(int(np.prod(s)) for _, s in self.parts)

    def unpack(self, th):
        out, k = {}, 0
        for n, s in self.parts:
            m = int(np.prod(s)); out[n] = th[k:k + m].reshape(s); k += m
        return out

    def pack(self, d):
        return np.concatenate([np.asarray(d[n], float).ravel() for n, _ in self.parts])


def head_scores(p, A, F, L, use_wind=True):
    c = A['course'] - 1; v = A['venue'][:, None]
    s = p['P'][c] + p['V'][v, c]
    for k, f in enumerate(L.fh): s = s + p['B'][k] * F[f]
    if use_wind:
        w = A['wind'][:, None].astype(float); h = A['wave'][:, None].astype(float)
        s = s + w * p['W'][c] + h * p['H'][c]
        d = A['wdir']; vd = np.where(d >= 0, p['VD'][A['venue'], np.maximum(d, 0)], 0) * A['wind']
        s = s + (c == 0) * vd[:, None]
    return s


def himo_scores(p, A, F, L, winner):
    c = A['course'] - 1
    cw = c[np.arange(len(c)), winner]
    q = p['D'][cw[:, None], c]
    for k, f in enumerate(L.fm): q = q + p['G'][k] * F[f]
    return q


def softmax_masked(s, mask):
    s = np.where(mask, s, -np.inf); m = s.max(1, keepdims=True)
    e = np.exp(s - m); return e / e.sum(1, keepdims=True)


def nll_and_grad(th, A, F, L, lam):
    p = L.unpack(th); n = len(A['date']); idx = np.arange(n)
    c = A['course'] - 1; v = A['venue']; t = A['tri']
    g = {k: np.zeros_like(val) for k, val in p.items()}
    # ---- 頭
    s = head_scores(p, A, F, L)
    ph = softmax_masked(s, np.ones_like(s, bool))
    nll = -np.log(ph[idx, t[:, 0]] + 1e-300).sum()
    gs = ph.copy(); gs[idx, t[:, 0]] -= 1                     # d nll / d s
    np.add.at(g['P'], c.ravel(), gs.ravel())
    np.add.at(g['V'], (np.repeat(v, 6), c.ravel()), gs.ravel())
    for k, f in enumerate(L.fh): g['B'][k] = (gs * F[f]).sum()
    w = A['wind'][:, None].astype(float); h = A['wave'][:, None].astype(float)
    np.add.at(g['W'], c.ravel(), (gs * w).ravel()); np.add.at(g['H'], c.ravel(), (gs * h).ravel())
    d = A['wdir']; ok = d >= 0
    g1 = (gs * (c == 0)).sum(1) * A['wind']
    np.add.at(g['VD'], (v[ok], d[ok]), g1[ok])
    # ---- ヒモ（2着・3着）
    q = himo_scores(p, A, F, L, t[:, 0])
    m2 = np.ones((n, 6), bool); m2[idx, t[:, 0]] = False
    p2 = softmax_masked(q, m2)
    m3 = m2.copy(); m3[idx, t[:, 1]] = False
    p3 = softmax_masked(q, m3)
    nll -= np.log(p2[idx, t[:, 1]] + 1e-300).sum() + np.log(p3[idx, t[:, 2]] + 1e-300).sum()
    gq = p2 + p3; gq[idx, t[:, 1]] -= 1; gq[idx, t[:, 2]] -= 1
    cw = c[idx, t[:, 0]]
    np.add.at(g['D'], (np.repeat(cw, 6), c.ravel()), gq.ravel())
    for k, f in enumerate(L.fm): g['G'][k] = (gq * F[f]).sum()
    # ---- 正則化（場ごとの値は強めに0へ寄せる）
    for k in p:
        l = lam.get(k, lam['_']); nll += l * (p[k] ** 2).sum(); g[k] = g[k] + 2 * l * p[k]
    return nll, L.pack(g)


def fit(A, F, L, lam, th0=None, maxiter=6000):
    th0 = np.zeros(L.size) if th0 is None else th0
    r = minimize(nll_and_grad, th0, args=(A, F, L, lam), jac=True, method='L-BFGS-B',
                 options=dict(maxiter=maxiter, maxfun=maxiter*2))
    return r.x, r


def trifecta_probs(th, A, F, L):
    """全120通りの確率 (n,6,6,6)"""
    p = L.unpack(th); n = len(A['date'])
    ph = softmax_masked(head_scores(p, A, F, L), np.ones((n, 6), bool))
    P = np.zeros((n, 6, 6, 6))
    for i in range(6):
        q = himo_scores(p, A, F, L, np.full(n, i))
        for j in range(6):
            if j == i: continue
            m2 = np.ones((n, 6), bool); m2[:, i] = False
            p2 = softmax_masked(q, m2)[:, j]
            m3 = m2.copy(); m3[:, j] = False
            p3 = softmax_masked(q, m3)
            for k in range(6):
                if k in (i, j): continue
                P[:, i, j, k] = ph[:, i] * p2 * p3[:, k]
    return P
