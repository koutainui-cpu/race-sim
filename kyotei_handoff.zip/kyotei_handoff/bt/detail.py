import numpy as np, json, features as fe, collections
R=fe.load('races.json'); A=fe.build(R)
O=json.load(open('odds.json'))
key=np.array([f"{d}_{fe.VENUES[v]}_{r}" for d,v,r in zip(A['date'],A['venue'],A['rno'])])
te=np.array([k in O for k in key])&(A['date']>='20260801')
keys=key[te]; rno=A['rno'][te]; ven=A['venue'][te]; pop=A['pop'][te]
d=np.load('bt_augsep.npz'); P,odds,tri,pay,date,course=d['P'],d['odds'],d['tri'],d['pay'],d['date'],d['course']
s=np.load('strategy2_out.npz'); a,b,t=float(s['a']),float(s['b']),float(s['t'])
valid=~np.isnan(odds); o=np.where(valid,odds,0)
inv=np.where(valid,1/np.where(valid,odds,1),0); Q=inv/inv.sum((1,2,3),keepdims=True)
X=np.where(valid,np.maximum(P,1e-12)**a*np.maximum(Q,1e-12)**b,0); X/=X.sum((1,2,3),keepdims=True)
EV=X*o
head1=np.zeros_like(P,bool)
for i in range(6): head1[:,i]=(course[:,i]==1)[:,None,None]
buy=valid&(EV>=t)&~(head1&(o<20)&(EV<max(t,1.6)))
out=[]
for n in np.where(buy.any((1,2,3)))[0]:
    bs=sorted([(EV[n,i,j,k],i,j,k) for i,j,k in zip(*np.where(buy[n]))],reverse=True)
    res=tuple(tri[n]); hit=any((i,j,k)==res for _,i,j,k in bs)
    heads={i for _,i,_,_ in bs}
    if hit: kind='的中'
    elif res[0] not in heads: kind='頭はずれ'
    elif any(i==res[0] and j==res[1] for _,i,j,_ in bs): kind='1-2着まで正解・3着違い'
    elif any(i==res[0] and (j in res[1:] and k in res[1:]) for _,i,j,k in bs): kind='頭正解・2-3着の順番違い'
    else: kind='頭正解・ヒモはずれ'
    cs=course[n]; shinyu='' if list(cs)==[1,2,3,4,5,6] else ' 進入'+''.join(str(int(x)) for x in np.argsort(cs)+1)
    out.append(dict(m=date[n][4:6],date=f"{int(date[n][4:6])}/{int(date[n][6:])}",v=fe.VNAME[ven[n]],r=int(rno[n]),shinyu=shinyu,
      bets=[f"{i+1}-{j+1}-{k+1}({o[n,i,j,k]:.0f}倍)" for _,i,j,k in bs],
      res=f"{res[0]+1}-{res[1]+1}-{res[2]+1}",pay=int(pay[n]),pop=int(pop[n]),kind=kind,
      ret=int(pay[n]) if hit else 0,stake=len(bs)*100,
      fav=f"{np.unravel_index(np.argmax(Q[n]),Q[n].shape)}"))
json.dump(out,open('detail.json','w'),ensure_ascii=False)
for m,lab in (('08','8月'),('09','9月')):
    L=[x for x in out if x['m']==m]
    print(f"===== {lab} {len(L)}レース 投資{sum(x['stake'] for x in L)} 払戻{sum(x['ret'] for x in L)}")
    print('  外れ方:',dict(collections.Counter(x['kind'] for x in L)))
    pts=[len(x['bets']) for x in L]; print('  点数の分布:',dict(sorted(collections.Counter(pts).items())))
    allb=[bb for x in L for bb in x['bets']]
    ods=[float(bb.split('(')[1][:-2]) for bb in allb]
    print('  買い目オッズ 中央値',np.median(ods),' 最小',min(ods),' 最大',max(ods))
    hc=collections.Counter(bb[0] for bb in allb); print('  買い目の頭(艇番)',dict(sorted(hc.items())))
    rp=[x['pop'] for x in L]; print('  結果の人気 中央値',np.median(rp))
    for x in L:
        print(f"  {x['date']} {x['v']}{x['r']}R{x['shinyu']} | 買い{len(x['bets'])}点: {' '.join(x['bets'])} | 結果 {x['res']} {x['pay']}円({x['pop']}人気) | {x['kind']}")
