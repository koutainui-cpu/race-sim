"""実際の最終オッズで、買い方ごとの回収率を確かめる（調整に使っていないレースで）"""
import numpy as np, json, sys, features as fe, model as M, deme
R=fe.load('races.json'); A=fe.build(R); F=fe.derived(A)
O=json.load(open('odds.json'))
sl=lambda D,m:{k:v[m] for k,v in D.items()}
tr=(A['date']>='20241101')&(A['date']<'20260901')
key=np.array([f"{d}_{fe.VENUES[v]}_{r}" for d,v,r in zip(A['date'],A['venue'],A['rno'])])
te=np.array([k in O for k in key])
print('学習',tr.sum(),'オッズ付き検証',te.sum())
base=['dwin','dlwin','dmot','dten','adv','fpos']; L=M.Layout(base,base)
At,Ft=sl(A,tr),sl(F,tr)
import os
if os.path.exists('theta_sep.npy'): th=np.load('theta_sep.npy')
else:
    th,_=M.fit(At,Ft,L,{'_':1e-3,'V':30,'VD':30}); np.save('theta_sep.npy',th)
if os.path.exists('eta_sep.npy'): eta=np.load('eta_sep.npy')
else:
    eta=deme.fit_eta(M.trifecta_probs(th,At,Ft,L),At,alpha=30); np.save('eta_sep.npy',eta)
Av,Fv=sl(A,te),sl(F,te)
P=deme.apply(M.trifecta_probs(th,Av,Fv,L),Av,eta)
odds=np.full(P.shape,np.nan)
for n,k in enumerate(key[te]):
    for c,o in O[k].items():
        i,j,l=map(int,c.split('-')); odds[n,i,j,l]=o if o else np.nan
np.savez('bt_data.npz',P=P,odds=odds,tri=Av['tri'],pay=Av['pay'],date=Av['date'],venue=Av['venue'],course=Av['course'])
# 払戻と最終オッズの照合
idx=np.arange(len(P)); t=Av['tri']
ow=odds[idx,t[:,0],t[:,1],t[:,2]]
print('的中組の最終オッズ×100 と 払戻 の差（中央値）',np.nanmedian(np.abs(ow*100-Av['pay'])))
