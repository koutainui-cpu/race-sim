// 現行アプリ（index.html）の予想ロジックをそのまま動かし、検証期間の結果と照合する
const fs=require('fs');
const html=fs.readFileSync('/mnt/user-data/outputs/race-sim-site/index.html','utf8');
const code=html.slice(html.indexOf('const DEF_CFG={'),html.indexOf('/* ---------- 計算 ---------- */'));
const races=JSON.parse(fs.readFileSync('val.json'));
const S=+process.argv[2]||4000;
const ctx=`const COLORS=[];const DEF_BOATS=[];const document={getElementById:()=>null};const localStorage={getItem:()=>null,setItem:()=>{}};
${code}; module.exports={setData:(d,e)=>{data=d;env=e},simOne,courses};`;
fs.writeFileSync('/tmp/claude-0/appmodel.js',ctx);
const AM=require('/tmp/claude-0/appmodel.js');
let llw=0,llt=0,hit=0,n=0; const pw=[0,0,0,0,0,0],aw=[0,0,0,0,0,0],p23=[0,0,0,0,0,0],a23=[0,0,0,0,0,0],cnt=[0,0,0,0,0,0];
for(const r of races){
  const d=r.boats.map(b=>({c:b.c,win:b.win,mot:b.mot,ten:b.ten,st:b.st??0.17,f:b.f,est:null}));
  AM.setData(d,{wind:r.wind,dir:"cross",wave:r.wave});
  const cs=d.map(b=>b.c), W=new Float64Array(6), T=new Map(), P23=new Float64Array(6);
  for(let s=0;s<S;s++){const o=AM.simOne(cs).order;W[o[0]]++;P23[o[1]]++;P23[o[2]]++;const k=o[0]*36+o[1]*6+o[2];T.set(k,(T.get(k)||0)+1)}
  const [a,b,c]=r.tri, kt=a*36+b*6+c;
  llw+=-Math.log((W[a]+.5)/(S+3)); llt+=-Math.log(((T.get(kt)||0)+.5)/(S+60));
  if(W.indexOf(Math.max(...W))===a) hit++;
  for(let i=0;i<6;i++){const ci=cs[i]-1;cnt[ci]++;pw[ci]+=W[i]/S;p23[ci]+=P23[i]/S;if(i===a)aw[ci]++;if(i===b||i===c)a23[ci]++}
  n++;
}
console.log(`== 現行アプリ（${n}レース, 各${S}回シミュ）`);
console.log(`  1着 対数損失 ${(llw/n).toFixed(3)}  本命的中 ${(hit/n*100).toFixed(1)}%  3連単 対数損失 ${(llt/n).toFixed(3)}`);
for(let k=0;k<6;k++) console.log(`   ${k+1}  ${(pw[k]/cnt[k]*100).toFixed(1)}/${(aw[k]/cnt[k]*100).toFixed(1)}   ${(p23[k]/cnt[k]*100).toFixed(1)}/${(a23[k]/cnt[k]*100).toFixed(1)}`);
