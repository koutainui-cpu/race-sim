"""公式テキスト（K=成績, B=番組表）から1レース1件のデータを作る"""
import re, os, sys, json, glob, collections

Z2H = str.maketrans('０１２３４５６７８９', '0123456789')
DIRS = ['北', '北北東', '北東', '東北東', '東', '東南東', '南東', '南南東',
        '南', '南南西', '南西', '西南西', '西', '西北西', '北西', '北北西']


def parse_B(path, ymd):
    """番組表：(場コード, R) -> {艇: {...}}"""
    out = {}
    jcd = None; rno = None
    for line in open(path, encoding='utf-8'):
        line = line.rstrip('\n')
        m = re.match(r'^(\d\d)BBGN', line)
        if m: jcd = m.group(1); continue
        m = re.match(r'^　?([０-９\d]+)Ｒ', line)
        if m and jcd:
            rno = int(m.group(1).translate(Z2H)); continue
        m = re.match(r'^([1-6]) (\d{4})', line)
        if m and jcd and rno:
            b = line.encode('cp932')
            def fw(a, z):
                try: return float(b[a:z].decode('cp932'))
                except: return None
            win, win2, lwin, mot, boat = fw(24, 29), fw(29, 35), fw(35, 40), fw(49, 55), fw(58, 64)
            if None in (win, mot): continue
            out.setdefault((jcd, rno), {})[int(m.group(1))] = dict(
                toban=m.group(2), win=win, win2=win2, lwin=lwin or 0.0, mot=mot, boat=boat,
                cls=b[22:24].decode('cp932', 'ignore'))
    return out


def parse_K(path, ymd):
    """成績：(場コード, R) -> {'env':..., 'rows':[...], 'tri':..., 'pay':..., 'pop':...}"""
    out = {}
    jcd = None; rno = None
    for line in open(path, encoding='utf-8'):
        line = line.rstrip('\n')
        m = re.match(r'^(\d\d)KBGN', line)
        if m: jcd = m.group(1); continue
        m = re.match(r'^\s+(\d{1,2})R\s+.*?H(\d+)m\s+(\S+)\s+風\s+(\S+?)　?\s*(\d+)m\s+波\s+(\d+)cm', line)
        if m and jcd:
            rno = int(m.group(1))
            d = m.group(4).replace('　', '')
            out[(jcd, rno)] = dict(weather=m.group(3).replace('　', ''), wdir=d,
                                   wind=int(m.group(5)), wave=int(m.group(6)), rows=[])
            continue
        m = re.match(r'^  (\S[\S ])  ([1-6]) (\d{4})', line)
        if m and jcd and rno and (jcd, rno) in out:
            b = line.encode('cp932')
            tail = b[29:].decode('cp932').split()
            if len(tail) < 5: continue
            def f(x):
                try: return float(x)
                except: return None
            st = tail[4]
            out[(jcd, rno)]['rows'].append(dict(
                rank=m.group(1), boat=int(m.group(2)), toban=m.group(3),
                ten=f(tail[2]), course=int(tail[3]) if tail[3].isdigit() else None,
                st=f(st.replace('F', '').replace('L', '')), fst=st.startswith('F'), lst=st.startswith('L')))
            continue
        m = re.match(r'^\s+３連単\s+(\d)-(\d)-(\d)\s+(\d+)\s+人気\s+(\d+)', line)
        if m and jcd and rno and (jcd, rno) in out and 'tri' not in out[(jcd, rno)]:
            out[(jcd, rno)]['tri'] = [int(m.group(1)), int(m.group(2)), int(m.group(3))]
            out[(jcd, rno)]['pay'] = int(m.group(4)); out[(jcd, rno)]['pop'] = int(m.group(5))
    return out


def build(txtdir):
    days = sorted(os.path.basename(p)[1:7] for p in glob.glob(os.path.join(txtdir, 'k*.txt')))
    races = []
    for ymd in days:
        kp = os.path.join(txtdir, f'k{ymd}.txt'); bp = os.path.join(txtdir, f'b{ymd}.txt')
        if not os.path.exists(bp): continue
        K = parse_K(kp, ymd); B = parse_B(bp, ymd)
        for key, k in K.items():
            if key not in B or 'tri' not in k or len(k['rows']) != 6: continue
            b = B[key]
            if len(b) != 6: continue
            boats = []
            ok = True
            for i in range(1, 7):
                r = next((x for x in k['rows'] if x['boat'] == i), None)
                if r is None or i not in b or r['toban'] != b[i]['toban']: ok = False; break
                boats.append(dict(b[i], ten=r['ten'], course=r['course'], st=r['st'],
                                  fst=r['fst'], lst=r['lst'], rank=r['rank']))
            if not ok: continue
            races.append(dict(date='20' + ymd, jcd=key[0], rno=key[1], wdir=k['wdir'], wind=k['wind'],
                              wave=k['wave'], weather=k['weather'], tri=k['tri'], pay=k['pay'],
                              pop=k['pop'], boats=boats))
    return races


if __name__ == '__main__':
    races = build(sys.argv[1])
    json.dump(races, open(sys.argv[2], 'w'), ensure_ascii=False)
    print('races', len(races), 'days', len({r['date'] for r in races}))
    c = collections.Counter(r['wdir'] for r in races); print(c.most_common(20))
