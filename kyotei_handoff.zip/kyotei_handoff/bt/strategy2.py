"""手順固定の検証。8月で「混ぜ方」と「期待値の基準（月20〜30レースに絞る値）」を決め、9月で1回だけ確かめる。"""
import numpy as np
d = np.load('bt_augsep.npz')
P, odds, tri, pay, date, course = d['P'], d['odds'], d['tri'], d['pay'], d['date'], d['course']
n = len(P); idx = np.arange(n)
valid = ~np.isnan(odds); o = np.where(valid, odds, 0)
inv = np.where(valid, 1 / np.where(valid, odds, 1), 0); Q = inv / inv.sum((1, 2, 3), keepdims=True)
hit = np.zeros_like(P, bool); hit[idx, tri[:, 0], tri[:, 1], tri[:, 2]] = True
head1 = np.zeros_like(P, bool)
for i in range(6): head1[:, i] = (course[:, i] == 1)[:, None, None]
AUG = date < '20260901'; SEP = ~AUG
days = lambda m: len(set(date[m]))

def blend(a, b):
    X = np.where(valid, np.maximum(P, 1e-12) ** a * np.maximum(Q, 1e-12) ** b, 0)
    return X / X.sum((1, 2, 3), keepdims=True)
def ll(X, m): return float(-np.log(X[idx[m], tri[m, 0], tri[m, 1], tri[m, 2]] + 1e-12).mean())

# 1) 混ぜ方：8月だけで決める
best = min(((ll(blend(a, b), AUG), a, b) for a in np.arange(0, 1.61, .1) for b in np.arange(0, 1.61, .1) if a + b > 0))
_, a, b = best; X = blend(a, b); EV = X * o
print(f'混ぜ方（8月で決定）: モデル^{a:.1f}×オッズ^{b:.1f}')
for nm, m in (('8月', AUG), ('9月', SEP)):
    print(f'  {nm} 3連単の対数損失  モデル {ll(P,m):.4f}  市場 {ll(Q,m):.4f}  混合 {ll(X,m):.4f}')

def select(t):
    buy = valid & (EV >= t)
    buy &= ~(head1 & (o < 20) & (EV < max(t, 1.6)))      # ② 1号艇頭20倍未満は強い根拠がない限り切る
    return buy
def result(buy, m, B=4000, seed=1):
    bm = buy & m[:, None, None, None]
    st = bm.sum((1, 2, 3)) * 100.0; rt = (bm & hit).sum((1, 2, 3)) * pay
    races = np.where(st > 0)[0]
    roi = rt.sum() / max(st.sum(), 1)
    r = np.random.default_rng(seed); s = []
    for _ in range(B):
        k = r.choice(races, len(races)) if len(races) else races
        s.append(rt[k].sum() / max(st[k].sum(), 1) if len(k) else 0)
    s = np.array(s)
    return dict(races=len(races), bets=int(bm.sum()), hits=int((bm & hit).any((1, 2, 3)).sum()), stake=st.sum(), ret=rt.sum(),
                roi=roi, lo=np.percentile(s, 5), hi=np.percentile(s, 95), p_over=float((s > 1).mean()),
                per_month=len(races) / max(days(m), 1) * 30)

# 2) 基準：8月で「月20〜30レース」に収まる値を決める（30レースを超えない最小の基準）
grid = np.round(np.arange(1.0, 4.01, 0.05), 2)
chosen = None
for t in grid:
    r = result(select(t), AUG)
    if r['per_month'] <= 30: chosen = t; break
print(f'\n期待値の基準（8月で決定）: {chosen}  ← 月30レース以下になる最小の値')
for nm, m in (('8月（基準を決めた期間）', AUG), ('9月（初見・本番の確認）', SEP)):
    r = result(select(chosen), m)
    print(f'  {nm}: {r["races"]}レース（月換算{r["per_month"]:.0f}）{r["bets"]}点 的中{r["hits"]}レース '
          f'投資{r["stake"]:,.0f}円 払戻{r["ret"]:,.0f}円 回収率 {r["roi"]*100:.1f}%  90%幅 {r["lo"]*100:.0f}〜{r["hi"]*100:.0f}%  100%超えの確からしさ {r["p_over"]*100:.0f}%')

print('\n参考：基準ごとの結果（基準選びには8月だけを使用。9月の列は見るだけ）')
for t in (1.2, 1.5, 1.8, 2.0, 2.5, 3.0):
    ra = result(select(t), AUG); rs = result(select(t), SEP)
    print(f'  期待値≥{t:.1f}: 8月 {ra["races"]:4d}R 回収{ra["roi"]*100:6.1f}% | 9月 {rs["races"]:4d}R {rs["bets"]:4d}点 的中{rs["hits"]:3d} 回収{rs["roi"]*100:6.1f}% (90%幅 {rs["lo"]*100:.0f}〜{rs["hi"]*100:.0f}%)')
np.savez('strategy2_out.npz', a=a, b=b, t=chosen)
