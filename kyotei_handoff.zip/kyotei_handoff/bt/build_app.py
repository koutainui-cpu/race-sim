"""推定した値をアプリ（index.html）に組み込む"""
import json, sys, re, numpy as np, model as M

src, theta_path, info_path, dst = sys.argv[1:5]
t = open(src, encoding='utf-8').read()
L = M.Layout(M.FEATS, M.FEATS)
p = L.unpack(np.load(theta_path))
info = json.load(open(info_path))
# 定数のずれは確率に影響しないので見やすく中心化
P = p['P'] - p['P'].mean()
D = p['D'] - p['D'].mean(1, keepdims=True)
params = dict(P=P.round(4).tolist(), V=p['V'].round(4).tolist(), W=p['W'].round(4).tolist(), H=p['H'].round(4).tolist(),
              VD=p['VD'].round(4).tolist(), D=D.round(4).tolist(),
              B={k: round(float(v), 4) for k, v in zip(L.fh, p['B'])}, G={k: round(float(v), 4) for k, v in zip(L.fm, p['G'])},
              fh=[k for k in L.fh if k != 'dlwin'], fm=[k for k in L.fm if k != 'dlwin'],
              st_fill=info['st_fill'], f_add=info['f_add'], info=info['html'],
              eta=np.load(info['eta']).round(4).tolist(), blend=dict(a=info['a'], b=info['b']), take=1.337,
              cut=dict(odds=20, ev=1.6), kill=0.7, rank=[0.3, 0.6, 1.2])
eng = open('engine.js', encoding='utf-8').read().replace('__PARAMS__', json.dumps(params, ensure_ascii=False))

# --- モデル部分を差し替え
i = t.index('const DEF_CFG={'); j = t.index('function note(t){')
t = t[:i] + eng + t[j:]
# --- アニメ：確率どおりに抽選
t = t.replace('''  const cs=courses(); let r=simOne(cs);
  if(target){for(let k=0;k<4000&&r.order.slice(0,3).join("-")!==target;k++) r=simOne(cs);}''',
              '''  const cs=courses(); const r=simOne(cs,target);''')
t = t.replace('''(last?`<br><small>この3連単になる確率 ${pc?(pc/last.N*100).toFixed(1):"0.1未満"}%／${A.w+1}号艇の${A.r.kima}になる確率 ${(((last.kmBoat[A.w+"-"+A.r.kima]||0)/last.N)*100).toFixed(1)}%</small>`:"");''',
              '''(last?`<br><small>この3連単になる確率 ${pc?(pc/last.N*100).toFixed(1):"0.1未満"}%</small>`:"");''')
# --- 水面気象の入力欄
i = t.index('<div class="envrow">'); j = t.index('</div>', t.index('id="envWave"')) + len('</div>')
t = t[:i] + '''<div class="envrow">
      <label>場<select id="envVenue"></select></label>
      <label>風向き<select id="envDir"></select></label>
      <label>風速(m)<input id="envWind" inputmode="decimal"></label>
      <label>波高(cm)<input id="envWave" inputmode="decimal"></label>
    </div>''' + t[j:]
t = re.sub(r'<p class="note">展示STはフライングなら.*?</p>',
           '<p class="note">展示STはフライングなら「F.02」のように入力します。風速と波高はスクショから自動で入ります。<b>場と風向きはここで選んでください</b>（同じ風向きでも、場によって追い風・向かい風が違うため、場ごとの過去データから効き方を決めています）。</p>', t, flags=re.S)
t = t.replace('store("kyotei-sim-env",env); buildEnv();', 'store("kyotei-sim-env2",env); buildEnv();')
# --- 設定欄
i = t.index('<summary>'); j = t.index('<div class="btns"><button id="btnCfgReset">')
t = t[:i] + '''<summary>モデルの中身・設定</summary>
    <div class="fitinfo" id="fitInfo"></div>
    <h2 style="margin-top:12px">設定</h2>
    <div class="cfg" id="misc"></div>
    ''' + t[j:]
t = t.replace('.toast{position:fixed;', '.fitinfo{font-size:13px;line-height:1.7;color:var(--text)}.fitinfo table{min-width:0;font-size:12px}.fitinfo td,.fitinfo th{padding:3px 6px}\n.toast{position:fixed;', 1)
t = t.replace('<h2>3連単と期待値</h2>', '<h2>3連単と期待値</h2>\n    <div class="rankrow" id="rank"></div>', 1)
t = t.replace('<h2 style="margin-top:12px">買い目候補</h2><div class="buys" id="buys"></div>',
              '<h2 style="margin-top:12px">買い目候補</h2><div class="buys" id="buys"></div>\n    <div class="mine" id="mine"></div>', 1)
t = re.sub(r'<p class="note" style="margin-top:0">「適正」は確率どおりなら.*?</p>',
  '<p class="note" style="margin-top:0">期待値はモデルとオッズを混ぜた確率×オッズです（過去の検証でモデル単独より成績が良かったため）。「消し」はモデルが市場よりかなり低く見ている組で、過去データでは回収率が特に低かった組です。万舟まで狙うときは、オッズ一覧を下までスクショして読み込ませてください。</p>', t, flags=re.S)
t = re.sub(r'<p class="note">1着は「頭の点数」で決め.*?</p>',
  '<p class="note">頭（1着）とヒモ（2・3着）は別々の点数で決め、効き具合は過去約10万レースから推定しています。ヒモのコース欄には「1着艇のコース×自分のコース」の展開の傾向が入っています。最後にコースの並びごとの出やすさ（出目）で補正しています。</p>', t, flags=re.S)
t = t.replace('ol.combos li{display:grid;grid-template-columns:auto 1fr 76px 88px;', 'ol.combos li{display:grid;grid-template-columns:22px auto 1fr 70px 84px;')
t = t.replace('.toast{position:fixed;', '''.rankrow{display:flex;align-items:center;gap:10px;margin:0 0 8px;font-weight:700}
.rankbadge{font-family:"Dela Gothic One",sans-serif;color:#fff;font-size:22px;width:42px;height:42px;border-radius:10px;display:flex;align-items:center;justify-content:center}
.synth,.mine{margin-top:8px;font-size:13px;background:var(--bg);border:1px solid var(--line);border-radius:10px;padding:8px 10px}
.synth b,.mine b{font-size:15px;color:var(--accent)}
li.kill{opacity:.55}.killtag{color:#e53935}
.pick input{width:18px;height:18px}
.toast{position:fixed;''', 1)
open(dst, 'w', encoding='utf-8').write(t)
print('ok', len(t))
