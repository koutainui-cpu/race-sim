const PARAMS=__PARAMS__;   // 過去レースから推定した値（頭・ヒモ・場・風・波）
const VNAME=['桐生','戸田','江戸川','平和島','多摩川','浜名湖','蒲郡','常滑','津','三国','びわこ','住之江','尼崎','鳴門','丸亀','児島','宮島','徳山','下関','若松','芦屋','福岡','唐津','大村'];
const DIR16=['北','北北東','北東','東北東','東','東南東','南東','南南東','南','南南西','南西','西南西','西','西北西','北西','北北西'];
const DEF_CFG={stMix:.4,margin:1.2};
const DEF_ENV={venue:-1,wind:0,dir:-1,wave:0};
const $=id=>document.getElementById(id);
function load(k,d){try{const s=localStorage.getItem(k);if(s)return JSON.parse(s)}catch(e){}return JSON.parse(JSON.stringify(d))}
function store(k,v){try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}}
let picks=new Set();
let data=load("kyotei-sim-v1",DEF_BOATS), cfg=load("kyotei-sim-cfg2",DEF_CFG), odds=load("kyotei-sim-odds",{}), log=load("kyotei-sim-log",[]), env=load("kyotei-sim-env2",DEF_ENV);
if(!Array.isArray(data)||data.length!==6) data=JSON.parse(JSON.stringify(DEF_BOATS));
cfg=Object.assign({},DEF_CFG,cfg); env=Object.assign({},DEF_ENV,env);
function chip(i){const [bg,fg]=COLORS[i];return `<span class="chip" style="background:${bg};color:${fg}">${i+1}</span>`}
function combo(k){return `<span class="combo">${k.split("-").map(Number).map((x,j)=>chip(x)+(j<2?"<i>-</i>":"")).join("")}</span>`}
function courses(){const cs=data.map(b=>b.c);return new Set(cs).size===6?cs:[1,2,3,4,5,6]}
const num=v=>typeof v==="number"&&Number.isFinite(v);

/* ---------- 想定ST（平均ST×展示ST） ---------- */
function predST(b){
  let base=(num(b.st)?b.st:PARAMS.st_fill)+(b.f>=1?PARAMS.f_add:0);
  if(!num(b.est)) return {st:base,from:"平均"};
  let ex=b.est<0?.01:b.est;
  if(b.f>=1&&b.est<.05) ex=Math.max(ex,.05);
  return {st:(1-cfg.stMix)*base+cfg.stMix*ex,from:"平均+展示"};
}
/* ---------- 特徴（6艇の平均との差）---------- */
function feats(cs){
  const dev=k=>{const xs=data.map(b=>b[k]);const ok=xs.filter(num);const m=ok.length?ok.reduce((a,b)=>a+b,0)/ok.length:0;return xs.map(x=>num(x)?x-m:0)};
  const dwin=dev("win"), dmot=dev("mot"), dten=dev("ten").map(x=>-x);
  const pst=data.map(b=>predST(b).st);
  const adv=pst.map((s,i)=>{const inner=pst.filter((_,j)=>cs[j]<cs[i]);
    if(inner.length) return inner.reduce((a,b)=>a+b,0)/inner.length-s;
    const oth=pst.filter((_,j)=>j!==i);return .5*(oth.reduce((a,b)=>a+b,0)/oth.length-s)});
  return {dwin,dlwin:[0,0,0,0,0,0],dmot,dten,adv,fpos:data.map(b=>b.f>=1?1:0),pst};
}
function vdAt(v,d16){ // 16方位 -> 推定値（8方位の間は平均）
  if(v<0||d16<0) return 0; const row=PARAMS.VD[v];
  return d16%2===0?row[d16/2]:(row[(d16-1)/2]+row[((d16+1)/2)%8])/2;
}
function headParts(cs,F){
  const p=PARAMS, w=+env.wind||0, h=+env.wave||0, v=env.venue;
  return data.map((_,i)=>{const c=cs[i]-1;
    const course=p.P[c]+(v>=0?p.V[v][c]:0);
    const wind=w*p.W[c]+h*p.H[c]+(c===0?vdAt(v,env.dir)*w:0);
    const o={course,wind};
    for(const k of p.fh) o[k]=p.B[k]*F[k][i];
    return o});
}
function himoParts(cs,F,cw){
  const p=PARAMS;
  return data.map((_,i)=>{const o={course:p.D[cw-1][cs[i]-1]};for(const k of p.fm) o[k]=p.G[k]*F[k][i];return o});
}
const sum=o=>Object.values(o).reduce((a,b)=>a+b,0);
function softmax(arr,mask){let m=-1e9;arr.forEach((x,i)=>{if(mask[i]&&x>m)m=x});const e=arr.map((x,i)=>mask[i]?Math.exp(x-m):0);const s=e.reduce((a,b)=>a+b,0);return e.map(x=>x/s)}

/* ---------- 確率（全120通りを直接計算） ---------- */
let last=null;
function calc(){
  const cs=courses(), F=feats(cs);
  const H=headParts(cs,F).map(sum), ph=softmax(H,[1,1,1,1,1,1]);
  const raw=new Map(); let Z=0;
  for(let i=0;i<6;i++){
    const q=himoParts(cs,F,cs[i]).map(sum);
    const m2=[0,1,2,3,4,5].map(x=>x!==i), p2=softmax(q,m2);
    for(let j=0;j<6;j++){ if(j===i) continue;
      const m3=m2.map((x,k)=>x&&k!==j), p3=softmax(q,m3);
      for(let k=0;k<6;k++){ if(!m3[k]) continue;
        // ⑤ 出目補正（コースの並びごとの出やすさ）
        const ci=(cs[i]-1)*36+(cs[j]-1)*6+(cs[k]-1);
        const pr=ph[i]*p2[j]*p3[k]*Math.exp(PARAMS.eta[ci]); raw.set(i+"-"+j+"-"+k,pr); Z+=pr; } } }
  const tri=new Map(), win=[0,0,0,0,0,0], top2=[0,0,0,0,0,0], top3=[0,0,0,0,0,0], himo=[0,0,0,0,0,0];
  for(const [k,v] of raw){const p=v/Z; tri.set(k,p); const [i,j,l]=k.split("-").map(Number);
    win[i]+=p; top2[i]+=p; top2[j]+=p; top3[i]+=p; top3[j]+=p; top3[l]+=p; himo[j]+=p; himo[l]+=p;}
  // オッズがあるときは「モデル×オッズ」の混合確率で期待値を出す（モデル単独より実績が良かったため）
  const B=PARAMS.blend, pb=new Map(); let Zb=0;
  for(const [k,p] of tri){const o=parseFloat(odds[k]); const q=o>1?(1/o)/PARAMS.take:p;
    const v=Math.pow(p,B.a)*Math.pow(q,B.b); pb.set(k,v); Zb+=v;}
  for(const [k,v] of pb) pb.set(k,v/Zb);
  last={N:1,win,top2,top3,himo,tri,pb,cs,F,ph,sorted:[...tri.entries()].sort((a,b)=>b[1]-a[1])};
  render();
}
let calcT; function recalc(){clearTimeout(calcT);calcT=setTimeout(calc,150)}
/* アニメ用：確率どおりに1レースを抽選し、STと決まり手を付ける */
function normal(){let u=0,v=0;while(!u)u=Math.random();while(!v)v=Math.random();return Math.sqrt(-2*Math.log(u))*Math.cos(2*Math.PI*v)}
function simOne(cs,target){
  if(!last) calc();
  let key=target;
  if(!key){let r=Math.random();for(const [k,p] of last.sorted){r-=p;if(r<=0){key=k;break}} key=key||last.sorted[0][0]}
  const order=key.split("-").map(Number); order.push(...[0,1,2,3,4,5].filter(x=>!order.includes(x)));
  const pst=last.F.pst, w=order[0], c=cs[w];
  let st;
  for(let t=0;t<30;t++){ st=pst.map(s=>Math.max(.01,s+normal()*.03));
    const inner=st.filter((_,j)=>cs[j]<c), a=inner.length?inner.reduce((x,y)=>x+y,0)/inner.length-st[w]:0;
    if(c===1||a>-.02) break; }
  const inner=st.filter((_,j)=>cs[j]<c), a=inner.length?inner.reduce((x,y)=>x+y,0)/inner.length-st[w]:0;
  let kima; if(c===1) kima="逃げ"; else if(c===2) kima=a>.05?"まくり":"差し";
  else if(c<=4) kima=a>.04?"まくり":"まくり差し"; else kima=a>.06?"まくり":"まくり差し";
  return {order,st,kima,cs};
}

/* ---------- 表示 ---------- */
function bars(arr,el,side){
  const mx=Math.max(...arr,1e-9);
  $(el).innerHTML=arr.map((v,i)=>`<div class="bar">${chip(i)}<div class="track"><div class="fill${side?" alt":""}" style="width:${v/mx*100}%"></div></div><span class="v">${(v*100).toFixed(1)}%</span>${side?`<span class="v2">${side(i)}</span>`:""}</div>`).join("");
}
function render(){
  if(!last) return; const L=last;
  const p=L.win, fav=p.indexOf(Math.max(...p)), pv=p[fav]*100;
  const lvl=pv>=60?["堅い","#2e9e4f"]:pv>=40?["本命有力","#1e63d6"]:pv>=28?["混戦","#e08a00"]:["荒れ模様","#e53935"];
  const hFav=L.himo.indexOf(Math.max(...L.himo.map((v,i)=>i===fav?-1:v)));
  const dirTxt=env.dir>=0?DIR16[env.dir]:"風向き未選択";
  $("summary").innerHTML=`<div class="sum-main"><span class="badge" style="background:${lvl[1]}">${lvl[0]}</span>
    <span>頭 ${chip(fav)} 1着率 <b>${pv.toFixed(1)}%</b></span><span>ヒモ筆頭 ${chip(hFav)}</span></div>
    <div class="sum-sub">最有力の3連単 ${combo(L.sorted[0][0])} <b>${(L.sorted[0][1]*100).toFixed(1)}%</b>
    ／ 上位10通りで全体の <b>${(L.sorted.slice(0,10).reduce((s,x)=>s+x[1],0)*100).toFixed(0)}%</b> をカバー</div>
    <div class="sum-sub">${env.venue>=0?VNAME[env.venue]:"場未選択"}　${dirTxt} ${env.wind||0}m ／ 波 ${env.wave||0}cm${windNote()}</div>`;
  bars(L.win,"winBars",i=>`3連対${(L.top3[i]*100).toFixed(0)}%`);
  bars(L.himo,"himoBars",i=>`2着${((L.top2[i]-L.win[i])*100).toFixed(0)}%`);
  const top=L.sorted.slice(0,12);
  $("combos").innerHTML=top.map(([k,pr])=>{const o=parseFloat(odds[k]), ev=evOf(k), good=ev&&ev>=cfg.margin, kill=o>1&&killed(k);
    return `<li class="${good?"good":""}${kill?" kill":""}"><label class="pick"><input type="checkbox" data-pick="${k}" ${picks.has(k)?"checked":""}></label>${combo(k)}<span class="pr">${(pr*100).toFixed(1)}%<small>適正 ${(1/pr).toFixed(1)}倍</small></span>
      <input class="oddsIn" data-k="${k}" inputmode="decimal" placeholder="オッズ" value="${odds[k]||""}">
      <span class="ev">${kill?`<b class="killtag">消し</b>`:ev?`期待値 <b>${ev.toFixed(2)}</b>`:"—"}</span></li>`}).join("");
  $("combos").querySelectorAll("[data-pick]").forEach(el=>el.onchange=()=>{el.checked?picks.add(el.dataset.pick):picks.delete(el.dataset.pick);render()});
  $("combos").querySelectorAll(".oddsIn").forEach(el=>el.addEventListener("change",()=>{
    const v=parseFloat(el.value); if(Number.isFinite(v)&&v>1) odds[el.dataset.k]=v; else delete odds[el.dataset.k];
    store("kyotei-sim-odds",odds); render();}));
  const buys=buyList(), hasOdds=Object.keys(odds).length>0;
  const [rk,rc,rt]=rankOf(buys), S=synth(buys);
  $("rank").innerHTML=hasOdds?`<span class="rankbadge" style="background:${rc}">${rk}</span><span>${rt}</span>`:`<span class="empty">オッズを入れるとランクが出ます</span>`;
  $("buys").innerHTML=buys.length?buys.map(b=>`<span class="buy">${combo(b.k)} ${b.o}倍 期待値${b.ev.toFixed(2)}</span>`).join("")+
    `<div class="synth">合成オッズ <b>${S.odds.toFixed(1)}倍</b>（${S.n}点）／ 的中率 ${(S.p*100).toFixed(1)}% ／ 期待値 ${S.ev.toFixed(2)}</div>`:
    `<span class="empty">${hasOdds?"期待値が基準に届く買い目はありません（見送り推奨）":`オッズが入ると、期待値が基準（${cfg.margin.toFixed(2)}）以上の買い目がここに出ます`}</span>`;
  const mine=[...picks].filter(k=>parseFloat(odds[k])>1&&last.tri.has(k)).map(k=>({k,o:parseFloat(odds[k]),p:last.pb.get(k)})), M2=synth(mine);
  $("mine").innerHTML=M2?`自分で選んだ ${M2.n}点：合成オッズ <b>${M2.odds.toFixed(1)}倍</b> ／ 的中率 ${(M2.p*100).toFixed(1)}% ／ 期待値 <b>${M2.ev.toFixed(2)}</b>`:
    `<span class="empty">左のチェックで買い目を選ぶと、合成オッズを計算します（オッズ入力済みの組のみ）</span>`;
  // 根拠
  const cs=L.cs, F=L.F;
  const lab={course:"コース・場",wind:"風・波",dwin:"勝率",dmot:"モーター",dten:"展示",adv:"スタート",fpos:"F持ち"};
  const table=(P,keys,title)=>{const base=Math.max(...P.map(q=>q.course));
    return `<h3>${title}</h3><table class="why"><thead><tr><th></th>${keys.map(k=>`<th>${lab[k]}</th>`).join("")}<th>合計</th></tr></thead><tbody>`+
    P.map((q,i)=>{const vals=keys.map(k=>k==="course"?q.course-base:(q[k]||0));const tot=vals.reduce((a,b)=>a+b,0);
      return `<tr><td>${chip(i)}<small>${cs[i]}コース</small></td>${vals.map(v=>`<td class="${v>.05?"pos":v<-.05?"neg":""}">${v>0?"+":""}${v.toFixed(2)}</td>`).join("")}<td class="tot">${tot>0?"+":""}${tot.toFixed(2)}</td></tr>`}).join("")+`</tbody></table>`};
  const f2=n=>"."+String(Math.round(Math.abs(n)*100)).padStart(2,"0");
  const stRow=`<h3>想定ST（本番）</h3><div class="stline">${data.map((b,i)=>`<span>${chip(i)} <b>${f2(F.pst[i])}</b><small>平均${num(b.st)?f2(b.st):"—"}${num(b.est)?` 展示${b.est<0?"F":""}${f2(b.est)}`:""}${b.f?` F${b.f}`:""}</small></span>`).join("")}</div>`;
  $("why").innerHTML=stRow+
    table(headParts(cs,F),["course","wind","dwin","dmot","dten","adv","fpos"],"頭（1着）の点数")+
    table(himoParts(cs,F,cs[fav]),["course","dwin","dmot","dten","adv","fpos"],`ヒモ（2・3着）の点数　※${fav+1}号艇が1着のとき`);
  renderLog();
}
function windNote(){
  if(env.venue<0||env.dir<0||!(env.wind>0)) return "";
  const x=vdAt(env.venue,env.dir);
  return x>.015?"（この場ではイン有利の風）":x<-.015?"（この場ではイン不利の風）":"";
}
function evOf(k){const o=parseFloat(odds[k]);return o>1&&last?last.pb.get(k)*o:null}
function isHead1Cheap(k,o){const i=+k.split("-")[0];return last.cs[i]===1&&o<PARAMS.cut.odds}
function buyList(){
  if(!last) return []; const out=[];
  for(const k of Object.keys(odds)){const o=parseFloat(odds[k]), ev=evOf(k); if(!ev||!last.tri.has(k)) continue;
    if(ev<cfg.margin) continue;
    if(isHead1Cheap(k,o)&&ev<PARAMS.cut.ev) continue;          // ② 1号艇頭の安いオッズは強い根拠がない限り切る
    out.push({k,ev,o,p:last.pb.get(k)})}
  return out.sort((a,b)=>b.ev-a.ev);
}
function killed(k){const o=parseFloat(odds[k]);if(!(o>1)) return false;const q=(1/o)/PARAMS.take;return last.tri.get(k)/q<PARAMS.kill}
function synth(list){ // ④ 合成オッズ
  if(!list.length) return null; const inv=list.reduce((s,x)=>s+1/x.o,0), p=list.reduce((s,x)=>s+x.p,0);
  return {odds:1/inv,p,ev:p/inv,n:list.length};
}
function rankOf(buys){ // ③ おすすめランク
  if(!buys.length) return ["D","#7a8794","買い目なし（見送り）"];
  const sc=buys.reduce((s,b)=>s+(b.ev-1),0), R=PARAMS.rank;
  return sc>=R[2]?["S","#e53935","妙味大"]:sc>=R[1]?["A","#e08a00","妙味あり"]:sc>=R[0]?["B","#1e63d6","やや妙味"]:["C","#2e9e4f","小さな妙味"];
}

/* ---------- 入力欄 ---------- */
const fmtST=v=>!num(v)?"":(v<0?"F":"")+"."+String(Math.round(Math.abs(v)*100)).padStart(2,"0");
function parseST(s){s=String(s).trim().toUpperCase();if(!s)return null;const f=s.startsWith("F");const n=parseFloat(s.replace("F","").replace(/^\./,"0."));
  if(!Number.isFinite(n))return null;const v=n>=1?n/100:n;return f?-v:v}
function buildRows(){
  $("rows").innerHTML=data.map((b,i)=>`<tr><td>${chip(i)}${b.f?`<small class="fbadge">F${b.f}</small>`:""}</td>
    <td><select data-i="${i}" data-k="c">${[1,2,3,4,5,6].map(v=>`<option ${v==b.c?"selected":""}>${v}</option>`).join("")}</select></td>
    ${["win","st","mot","ten"].map(k=>`<td><input data-i="${i}" data-k="${k}" inputmode="decimal" value="${num(b[k])?b[k]:""}"></td>`).join("")}
    <td><input data-i="${i}" data-k="est" value="${fmtST(b.est)}" placeholder="—"></td></tr>`).join("");
  $("rows").querySelectorAll("input,select").forEach(el=>el.addEventListener("change",()=>{
    const i=+el.dataset.i,k=el.dataset.k;
    if(k==="est"){data[i].est=parseST(el.value);}
    else{const v=parseFloat(el.value); if(!Number.isFinite(v)) return; data[i][k]=v;}
    store("kyotei-sim-v1",data);
    if(k==="c"&&new Set(data.map(b=>b.c)).size<6) note("進入が重複しています。重複中は枠なりで計算します");
    recalc();}));
}
function buildEnv(){
  $("envVenue").innerHTML=`<option value="-1">選択</option>`+VNAME.map((n,i)=>`<option value="${i}">${n}</option>`).join("");
  $("envDir").innerHTML=`<option value="-1">無風・不明</option>`+DIR16.map((n,i)=>`<option value="${i}">${n}</option>`).join("");
  $("envVenue").value=env.venue; $("envWind").value=env.wind||0; $("envDir").value=env.dir; $("envWave").value=env.wave||0;
  ["envVenue","envWind","envDir","envWave"].forEach(id=>$(id).onchange=()=>{
    env={venue:+$("envVenue").value,wind:parseFloat($("envWind").value)||0,dir:+$("envDir").value,wave:parseFloat($("envWave").value)||0};
    store("kyotei-sim-env2",env); recalc();});
}
function buildCfg(){
  $("misc").innerHTML=`<label>想定STの展示比重（0〜1）<input data-x="stMix" inputmode="decimal" value="${cfg.stMix}"></label>
    <label>買いの基準（期待値）<input data-x="margin" inputmode="decimal" value="${cfg.margin}"></label>`;
  document.querySelectorAll("#misc input").forEach(el=>el.addEventListener("change",()=>{
    const v=parseFloat(el.value); if(!Number.isFinite(v)) return;
    if(el.dataset.x==="stMix") cfg.stMix=Math.min(1,Math.max(0,v)); else cfg.margin=v;
    store("kyotei-sim-cfg2",cfg); recalc();}));
  $("btnCfgReset").onclick=()=>{cfg=JSON.parse(JSON.stringify(DEF_CFG));store("kyotei-sim-cfg2",cfg);buildCfg();recalc()};
  $("fitInfo").innerHTML=PARAMS.info;
}
