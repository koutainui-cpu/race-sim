// data/K, data/B の LZH をすべて UTF-8 テキストに展開する
const {extractLzh}=require('../lzh.js');const fs=require('fs');const path=require('path');
const [src,dst]=process.argv.slice(2); fs.mkdirSync(dst,{recursive:true});
const dec=new TextDecoder('shift_jis'); let n=0,skip=0;
for(const sub of ['K','B']) for(const f of fs.readdirSync(path.join(src,sub))){
  const out=path.join(dst,f.replace('.lzh','.txt')); if(fs.existsSync(out)){skip++;continue}
  try{for(const x of extractLzh(fs.readFileSync(path.join(src,sub,f)))) fs.writeFileSync(out,dec.decode(x.content)); n++}
  catch(e){console.error('NG',f,e.message)}
}
console.log('extracted',n,'skipped',skip);
