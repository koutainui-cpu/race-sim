"""手順固定：モデルは2026年7月までで学習し凍結。8月・9月のオッズ付きレースの確率を出しておく"""
import numpy as np, json, os, features as fe, model as M, deme
R=fe.load('races.json'); A=fe.build(R); F=fe.derived(A)
sl=lambda D,m:{k:v[m] for k,v in D.items()}
base=['dwin','dlwin','dmot','dten','adv','fpos']; L=M.Layout(base,base)
tr=(A['date']>='20241101')&(A['date']<'20260801')
if not os.path.exists('theta_jul.npy'):
    At,Ft=sl(A,tr),sl(F,tr)
    th,_=M.fit(At,Ft,L,{'_':1e-3,'V':30,'VD':30}); np.save('theta_jul.npy',th)
    eta=deme.fit_eta(M.trifecta_probs(th,At,Ft,L),At,alpha=30); np.save('eta_jul.npy',eta)
th=np.load('theta_jul.npy'); eta=np.load('eta_jul.npy')
O=json.load(open('odds.json'))
key=np.array([f"{d}_{fe.VENUES[v]}_{r}" for d,v,r in zip(A['date'],A['venue'],A['rno'])])
te=np.array([k in O for k in key])&(A['date']>='20260801')
Av,Fv=sl(A,te),sl(F,te)
P=deme.apply(M.trifecta_probs(th,Av,Fv,L),Av,eta)
odds=np.full(P.shape,np.nan)
for n,k in enumerate(key[te]):
    for c,o in O[k].items():
        i,j,l=map(int,c.split('-')); odds[n,i,j,l]=o if o else np.nan
np.savez('bt_augsep.npz',P=P,odds=odds,tri=Av['tri'],pay=Av['pay'],date=Av['date'],venue=Av['venue'],course=Av['course'])
print('学習',tr.sum(),' 8月',(Av['date']<'20260901').sum(),' 9月',(Av['date']>='20260901').sum())
