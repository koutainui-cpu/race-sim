"""⑤ 基本の出目：コースの並び（例 1-2-3, 4-1-…）ごとに、モデルの予想と実際の出現率のずれを学習して補正する"""
import numpy as np
def course_index(A):
    """各レースの120通り(i,j,k:艇)に対応するコースの並びの番号 (n,6,6,6) -> 0..215"""
    c = A['course'] - 1
    return c[:, :, None, None] * 36 + c[:, None, :, None] * 6 + c[:, None, None, :]
def fit_eta(P, A, alpha=30, iters=30):
    n = len(A['date']); idx = np.arange(n); t = A['tri']
    ci = course_index(A)
    obs = np.bincount(ci[idx, t[:, 0], t[:, 1], t[:, 2]], minlength=216).astype(float)
    eta = np.zeros(216)
    for _ in range(iters):
        Q = P * np.exp(eta[ci]); Q = Q / Q.sum((1, 2, 3), keepdims=True)
        pred = np.bincount(ci.ravel(), weights=Q.ravel(), minlength=216)
        eta += 0.7 * (np.log(obs + alpha * pred / max(pred.sum(), 1) * 0 + alpha) - np.log(pred + alpha))
    return eta
def apply(P, A, eta):
    Q = P * np.exp(eta[course_index(A)])
    return Q / Q.sum((1, 2, 3), keepdims=True)
