import numpy as np, features as fe, model as M, evaluate as E, itertools, time
R=fe.load('races.json')
base=['dwin','dlwin','dmot','dten','adv','fpos']
for win in (15,30,60):
    A=fe.build(R,st_window=win); F=fe.derived(A)
    tr=(A['date']>='20250901')&(A['date']<'20260701'); va=(A['date']>='20260701')&(A['date']<'20260901')
    sl=lambda D,m:{k:v[m] for k,v in D.items()}
    At,Ft,Av,Fv=sl(A,tr),sl(F,tr),sl(A,va),sl(F,va)
    for lv in ((2,) if win!=30 else (2,8,30)):
        t0=time.time(); L=M.Layout(base,base); th,r=M.fit(At,Ft,L,{'_':1e-3,'V':lv,'VD':lv})
        m=E.metrics(M.trifecta_probs(th,Av,Fv,L),Av)
        print(f"ST区間{win} λ{lv}: 学習{tr.sum()} 検証{va.sum()}  1着LL {m['win_ll']:.4f} 本命{m['win_hit']*100:.1f}% 3連単LL {m['tri_ll']:.4f} 市場 {m['mkt_ll']:.4f}  ({time.time()-t0:.0f}s)",flush=True)
