import numpy as np, features as fe, model as M, evaluate as E, deme
R=fe.load('races.json'); A=fe.build(R); F=fe.derived(A)
sl=lambda D,m:{k:v[m] for k,v in D.items()}
tr=(A['date']>='20250901')&(A['date']<'20260701'); va=(A['date']>='20260701')&(A['date']<'20260901')
At,Ft,Av,Fv=sl(A,tr),sl(F,tr),sl(A,va),sl(F,va)
base=['dwin','dlwin','dmot','dten','adv','fpos']; L=M.Layout(base,base)
th,_=M.fit(At,Ft,L,{'_':1e-3,'V':30,'VD':30}); np.save('theta_tr.npy',th)
Pt=M.trifecta_probs(th,At,Ft,L); Pv=M.trifecta_probs(th,Av,Fv,L)
E.show('補正なし',E.metrics(Pv,Av))
for a in (10,30,100):
    eta=deme.fit_eta(Pt,At,alpha=a); m=E.metrics(deme.apply(Pv,Av,eta),Av)
    print(f"出目補正 α{a}: 3連単LL {m['tri_ll']:.4f} 1着LL {m['win_ll']:.4f}")
    np.save(f'eta_{a}.npy',eta)
